# VXML Final Report Templates

This repository contains templates for the [PIMS
VXML](https://vxml.pims.math.ca) final reports. There are templates for both
$\LaTeX$ and Markdown reports. The [markdown template](./markdown), includes a
[pandoc](https://pandoc.org) header to allow us to produce PDF results which are
similar to those of the $\LaTeX$ template.
to produce a PDF version of your report.
